<?php
echo $datos;